# Inventory Search v0.1.6 Beta — Installer

**Test status:** Client DLL successfully tested in singleplayer; the installer needs a fresh-PC test.

1. Close Unturned. Extract the entire ZIP folder.
2. Double-click `INSTALL.cmd` and follow on-screen prompts.
3. If BepInEx 5 is missing, the installer gets the pinned, SHA-256-verified release from official BepInEx GitHub.
4. Launch without BattlEye. Press `G`, then `Ctrl+F`.

`UPDATE-NOW.cmd` checks the official release channel (`Tac0-0/Unturned-Inventory-Search`) once the GitHub release exists. The installer also tries to set up automatic checks at sign-in and daily. Updates are digest-verified and skipped while Unturned runs. `UNINSTALL.cmd` removes the plugin and scheduled task, leaving other mods untouched.

This is not a Steam Workshop mod, and subscribing or joining a server does not automatically install client DLL code.

Safety: run only on a PC you control and review scripts before running. Compatibility on servers protected by BattlEye is not supported.

Client DLL SHA-256: `405662cb3023da2d6cdd7d5d8ef62457e624d654489da8fb729a8a3141bed515`
